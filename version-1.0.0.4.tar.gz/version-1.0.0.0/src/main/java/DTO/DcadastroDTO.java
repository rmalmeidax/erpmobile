package DTO;

import Heranca.CadastroDTO;



public class DcadastroDTO extends CadastroDTO {

}
