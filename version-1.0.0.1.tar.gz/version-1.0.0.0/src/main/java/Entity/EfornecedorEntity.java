package Entity;

import java.util.ArrayList;
import java.util.List;

import Enum.EestadosBrEnum;
import Heranca.HcadastroHeranca;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tb_fornecedor")
@NoArgsConstructor
public class EfornecedorEntity  extends HcadastroHeranca{
	
	@OneToMany(mappedBy = "fornecedor", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<EcadastroEntity> cadastro = new ArrayList<>();
	
	
	
	@ManyToMany	
	@JoinTable(name = "tb_produtoFornecedor",
	joinColumns = @JoinColumn (name = "fornecedor_id"),
	inverseJoinColumns = @JoinColumn (name = "produtos_id")
	)
	private List<EprodutoEntity> produtos = new ArrayList<>();



	public List<EcadastroEntity> getCadastro() {
		return cadastro;
	}



	public void setCadastro(List<EcadastroEntity> cadastro) {
		this.cadastro = cadastro;
	}



	public List<EprodutoEntity> getProdutos() {
		return produtos;
	}



	public void setProdutos(List<EprodutoEntity> produtos) {
		this.produtos = produtos;
	}



	public EfornecedorEntity(Integer id, String nome, String cpf, String cnpj, String endereco, Integer numero,
			String bairro, String cidade, EestadosBrEnum estados, String cep, String email,
			List<EcadastroEntity> cadastro, List<EprodutoEntity> produtos) {
		super(id, nome, cpf, cnpj, endereco, numero, bairro, cidade, estados, cep, email);
		this.cadastro = cadastro;
		this.produtos = produtos;
	}
	
	
	

}
