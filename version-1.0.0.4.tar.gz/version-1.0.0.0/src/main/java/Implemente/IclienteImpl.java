package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DclienteDTO;
import Entity.EclienteEntity;
import MapStruct.MclienteMapStruct;
import Repository.RclienteRepository;
import Service.SclienteService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IclienteImpl implements SclienteService {

	private RclienteRepository repository;
	private MclienteMapStruct mapper;

	@Override
	public List<DclienteDTO> findAll() {
		List<EclienteEntity> entity = repository.findAll();
		return entity.stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DclienteDTO findById(Integer id) {
		EclienteEntity entity = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cliente com ID: " + id + "  não encontrado."));

		return mapper.toDto(entity);

	}

	@Override
	public Optional<DclienteDTO> save(DclienteDTO dto) {
		EclienteEntity entity = mapper.toEntity(dto);
		EclienteEntity entitySave = repository.save(entity);
		return Optional.of(mapper.toDto(entitySave));
	}

	@Override
	public void deleteById(Integer id) {
		repository.deleteById(id);

	}

	@Override
	public List<DclienteDTO> findByFirstNomeContaining(String palavraChave) {

		if (palavraChave == null || palavraChave.trim().isEmpty())
			return List.of();

		List<EclienteEntity> entity = repository.findByFirstNomeContaining(palavraChave);
		return entity.stream().map(mapper::toDto).collect(Collectors.toList());
	}

}
