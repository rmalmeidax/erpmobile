package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DfornecedorDTO;
import Entity.EfornecedorEntity;

@Mapper(componentModel = "spring")

public interface MfornecedorMapStruct {

	MfornecedorMapStruct fornecedor = Mappers.getMapper(MfornecedorMapStruct.class);

	DfornecedorDTO toDto(EfornecedorEntity entity);

	EfornecedorEntity toEntity(DfornecedorDTO dto);

}
