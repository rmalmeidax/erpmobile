package Heranca;

import java.util.Objects;

import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

import Enum.EestadosBrEnum;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.Email;



@Entity
@Inheritance(strategy = InheritanceType.JOINED)

public class HcadastroHeranca {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "nome", length = 100, nullable = false)
	private String nome;
	@CPF
	@Column(name = "CPF", length = 14, nullable = true)
	private String cpf;
	@CNPJ
	@Column(name = "CNPJ", length = 18, nullable = true)
	private String cnpj;
	@Column(name = "endereco", length = 100)

	private String endereco;
	@Column(name = "numero", length = 10)
	private Integer numero;
	@Column(name = "bairro", length = 50)
	private String bairro;
	@Column(name = "cidade", length = 50)
	private String cidade;

	@Enumerated(EnumType.STRING)
	@Column(name = "estados", length = 2)
	private EestadosBrEnum estados;

	@Column(name = "cep", length = 10)
	private String cep;
	@Email
	@Column(name = "email")
	private String email;
	public HcadastroHeranca(Integer id, String nome, @CPF String cpf, @CNPJ String cnpj, String endereco,
			Integer numero, String bairro, String cidade, EestadosBrEnum estados, String cep, @Email String email) {
		super();
		this.id = id;
		this.nome = nome;
		this.cpf = cpf;
		this.cnpj = cnpj;
		this.endereco = endereco;
		this.numero = numero;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estados = estados;
		this.cep = cep;
		this.email = email;
	}
	public HcadastroHeranca() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Integer getNumero() {
		return numero;
	}
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public EestadosBrEnum getEstados() {
		return estados;
	}
	public void setEstados(EestadosBrEnum estados) {
		this.estados = estados;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HcadastroHeranca other = (HcadastroHeranca) obj;
		return Objects.equals(id, other.id);
	}
	
	
	
	
	

}
