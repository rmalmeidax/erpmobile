package DTO;

import Entity.EfornecedorEntity;
import Entity.EunidadeEntity;
import Heranca.ProdutoBaseDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class DprodutoDTO  extends ProdutoBaseDTO{
	
	private EfornecedorEntity fornecedor;
	private EunidadeEntity unidade;
	

}
