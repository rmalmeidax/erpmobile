package Service;

import java.util.List;
import java.util.Optional;

import DTO.DestoqueDTO;

public interface SestoqueService {
	
	List<DestoqueDTO> findAll();

	DestoqueDTO findById(Integer id);

	Optional<DestoqueDTO> save(DestoqueDTO dto);

	void deleteById(Integer id);
	
	
	
	

}
