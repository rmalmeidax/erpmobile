package Heranca;

import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

import Enum.EestadosBrEnum;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Builder
@Inheritance(strategy = InheritanceType.JOINED)

public class CadastroDTO {

	private Integer id;
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "nome", length = 100, nullable = true)
	private String nome;
	
	@CPF
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cpf", length = 14, nullable = true)
	private String cpf;
	@CNPJ 
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cnpj", length = 18, nullable = true)
	private String cnpj;
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "endereco", length = 200, nullable = true)
	private String endereco;
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "numero", length = 10, nullable = true)
	private Integer numero;
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "bairro", length = 50, nullable = true)
	private String bairro;
	
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cidade", length = 100, nullable = true)
	private String cidade;
	
	@Enumerated(EnumType.STRING)
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "estados", length = 2, nullable = true)
	private EestadosBrEnum estados;
	
	
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cep", length = 10, nullable = true)
	private String cep;
	
	@Email
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "email", length = 50, nullable = true)
	private String email;

}
