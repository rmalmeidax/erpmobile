package Heranca;

import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

import Enum.EestadosBrEnum;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Builder
@Inheritance(strategy = InheritanceType.JOINED)

public class Cadastro {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "nome", length = 100, nullable = false)
	private String nome;

	@NotBlank(message = "Campo obrigátorio.")
	@CPF
	@Column(name = "CPF", length = 14, nullable = true)
	private String cpf;

	@NotBlank(message = "Campo obrigátorio.")
	@CNPJ
	@Column(name = "CNPJ", length = 18, nullable = true)
	private String cnpj;

	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "endereco", length = 100)
	private String endereco;

	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "numero", length = 10)
	private Integer numero;

	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "bairro", length = 50)
	private String bairro;

	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cidade", length = 50)
	private String cidade;

	@NotBlank(message = "Campo obrigátorio.")
	@Enumerated(EnumType.STRING)
	@Column(name = "estados", length = 2)
	private EestadosBrEnum estados;

	@Pattern(regexp = "\\ d{5}-?\\-d {3}", message = "CEP deve ter formato válido (00000-000 ou 00000000)")
	@NotBlank(message = "Campo obrigátorio.")
	@Column(name = "cep", length = 10)
	private String cep;

	@NotBlank(message = "Campo obrigátorio.")
	@Email
	@Column(name = "email")
	private String email;

}
