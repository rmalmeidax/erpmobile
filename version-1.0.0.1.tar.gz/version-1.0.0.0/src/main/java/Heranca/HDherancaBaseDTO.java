package Heranca;

import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Inheritance(strategy = InheritanceType.JOINED)
public class HDherancaBaseDTO {

	
	private Integer id;
	private Integer numeroProduto;
	private Double quantidade;
	private Double valorUnitario;
	private Double valorTotal;
	

	
	
}
