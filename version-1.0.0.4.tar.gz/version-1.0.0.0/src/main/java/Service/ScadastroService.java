package Service;

import java.util.List;
import java.util.Optional;

import DTO.DcadastroDTO;
import Entity.EcadastroEntity;

public interface ScadastroService {

	List<DcadastroDTO> findAll();

	 DcadastroDTO findById(Integer id);

	Optional<DcadastroDTO> save(DcadastroDTO dto);

	void deleteById(Integer id);

	List<DcadastroDTO> findByFirstNomeContaining (String palavraChave);
}
