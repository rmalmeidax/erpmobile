package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EcomprasEntity;

public interface RcomprasRepository extends JpaRepository<EcomprasEntity, Integer>{
	
	List<EcomprasEntity> findByFirstNomeContaining (String palavraChave);

}
