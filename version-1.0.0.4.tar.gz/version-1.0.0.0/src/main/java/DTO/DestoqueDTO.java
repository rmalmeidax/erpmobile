package DTO;

import Entity.EcomprasEntity;
import Entity.EprodutoEntity;
import Entity.EvendasEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class DestoqueDTO {
	
	
	private EprodutoEntity produto;
	private EcomprasEntity compras;
	private EvendasEntity preco;

}
