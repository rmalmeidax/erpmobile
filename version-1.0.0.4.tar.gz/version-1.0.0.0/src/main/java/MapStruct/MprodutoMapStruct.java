package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DprodutoDTO;
import Entity.EprodutoEntity;

@Mapper(componentModel = "spring")

public interface MprodutoMapStruct {

	MprodutoMapStruct produto = Mappers.getMapper(MprodutoMapStruct.class);

	DprodutoDTO toDto(EprodutoEntity entity);

	EprodutoEntity toEntity(DprodutoDTO dto);

}
