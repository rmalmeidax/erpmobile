package Entity;

import Heranca.Cadastro;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tb_cadastro")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EcadastroEntity extends Cadastro {

	@ManyToOne
	@JoinColumn(name = " cliente_id")
	private EclienteEntity cliente;

	@ManyToOne
	@JoinColumn(name = " fornecedor_id")
	private EfornecedorEntity fornecedor;

	
}
