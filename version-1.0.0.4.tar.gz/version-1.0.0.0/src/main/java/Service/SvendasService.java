package Service;

import java.util.List;
import java.util.Optional;

import DTO.DvendasDTO;
import Entity.EvendasEntity;

public interface SvendasService {
	
	List<DvendasDTO> findAll();

	DvendasDTO findById(Integer id);

	Optional<DvendasDTO> save(DvendasDTO dto);

	void deleteById(Integer id);
	
	List<EvendasEntity> findByFirstNomeContaining (String palavraChave);

}
