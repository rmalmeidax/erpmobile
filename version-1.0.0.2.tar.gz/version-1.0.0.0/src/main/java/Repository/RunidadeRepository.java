package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EunidadeEntity;

public interface RunidadeRepository extends JpaRepository<EunidadeEntity, Integer>{
	
	List <EunidadeEntity> findByFirstNomeContaining (String palavraChave);

}
