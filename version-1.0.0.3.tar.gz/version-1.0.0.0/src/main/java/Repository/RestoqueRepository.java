package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EestoqueEntity;

public interface RestoqueRepository  extends JpaRepository<EestoqueEntity, Integer>{
	
	List<EestoqueEntity> findByFirstNomeContaining (String palavraChave);

}
