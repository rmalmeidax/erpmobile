package Entity;

import java.util.ArrayList;
import java.util.List;

import Heranca.ProdutoBase;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 */
@Entity
@Table(name = "tb_compras")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EcomprasEntity extends ProdutoBase {
	
	
	
	@ManyToMany(mappedBy = "compras")
	
	private List<EestoqueEntity> estoque = new ArrayList<>();

	@ManyToMany
	@JoinTable(name = "tb_compras_fornecedor", joinColumns = @JoinColumn(name = "compras_id"), 
	inverseJoinColumns = @JoinColumn(name = "fornecedor_id")

	)
	private List<EfornecedorEntity> fornecedores = new ArrayList<>();

	
	
}
