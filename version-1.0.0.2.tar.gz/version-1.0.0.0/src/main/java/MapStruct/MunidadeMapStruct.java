package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DunidadeDTO;
import Entity.EunidadeEntity;

@Mapper(componentModel = "spring")

public interface MunidadeMapStruct {

	MunidadeMapStruct unidade = Mappers.getMapper(MunidadeMapStruct.class);

	DunidadeDTO toDto(EunidadeEntity entity);

	EunidadeEntity toEntity(DunidadeDTO dto);

}
