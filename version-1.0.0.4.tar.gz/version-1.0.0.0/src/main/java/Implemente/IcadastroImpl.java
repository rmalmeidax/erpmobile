package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DcadastroDTO;
import Entity.EcadastroEntity;
import MapStruct.McadastroMapStruct;
import Repository.RcadastroRepository;
import Service.ScadastroService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class IcadastroImpl implements ScadastroService {

	private RcadastroRepository repository;
	private McadastroMapStruct mapper;

	@Override
	public List<DcadastroDTO> findAll() {

		List<EcadastroEntity> entity = repository.findAll();

		if (entity.isEmpty()) {
			return List.of();
		}

		return entity.stream().map(mapper::toDto).collect(Collectors.toList());

	}

	@Override
	public DcadastroDTO findById(Integer id) {
		EcadastroEntity entity = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cadastro com ID: " + id + "  não encontrado"));
		return mapper.toDto(entity);
	}

	@Override
	public Optional<DcadastroDTO> save(DcadastroDTO dto) {
		EcadastroEntity entity = mapper.toEntity(dto);
		EcadastroEntity entitySave = repository.save(entity);
		return Optional.of(mapper.toDto(entitySave));
	}

	@Override
	public void deleteById(Integer id) {
						
	repository.deleteById(id);
		
		
		
	}

	@Override
	public List<DcadastroDTO> findByFirstNomeContaining(String palavraChave) {

		if (palavraChave == null || palavraChave.trim().isEmpty()) {

			return List.of();
		}

		List<EcadastroEntity> entity = repository.findByFirstNomeContaining(palavraChave);
		return entity.stream().map(mapper::toDto).collect(Collectors.toList());
	}

}
