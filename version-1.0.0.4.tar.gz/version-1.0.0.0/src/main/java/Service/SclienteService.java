package Service;

import java.util.List;
import java.util.Optional;

import DTO.DclienteDTO;
import Entity.EclienteEntity;
import Entity.EprodutoEntity;

public interface SclienteService {

	List<DclienteDTO> findAll();

	DclienteDTO findById(Integer id);

	Optional<DclienteDTO> save(DclienteDTO dto);

	void deleteById(Integer id);

	List<DclienteDTO> findByFirstNomeContaining(String palavraChave);
}
