package Service;

import java.util.List;
import java.util.Optional;

import DTO.DunidadeDTO;

public interface SunidadeService {

	List<DunidadeDTO> findAll();

	DunidadeDTO findById(Integer id);

	Optional<DunidadeDTO> save(DunidadeDTO dto);

	void deleteById(Integer id);

}
