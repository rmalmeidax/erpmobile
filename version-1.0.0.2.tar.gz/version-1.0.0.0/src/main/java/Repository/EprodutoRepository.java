package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EprodutoEntity;

public interface EprodutoRepository extends JpaRepository<EprodutoEntity, Integer>{
	
	List<EprodutoEntity> findByFirstNomeContaining (String palavraChave);

}
