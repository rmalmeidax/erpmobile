package Heranca;

import java.util.List;

import Entity.EprodutoEntity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Builder
@Inheritance(strategy = InheritanceType.JOINED)

public class ProdutoBase {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "numeroProduto")
	private Integer numeroProduto;

	@NotNull(message = "Quantidade é obrigatória")
	@Positive(message = "Quantidade deve ser positiva")
	@Column(name = "quantidade", precision = 8, scale = 2)
	private Double quantidade; 

	@NotNull(message = "Quantidade é obrigatória")
	@Positive(message = "Quantidade deve ser positiva")
	@Column(name = "valorUnitario")
	private Double valorUnitario;
	
	
	@NotNull(message = "Quantidade é obrigatória")
	@Positive(message = "Quantidade deve ser positiva")
	@Transient
	private Double valorTotal;

	@OneToMany(mappedBy = "produtobase", cascade = CascadeType.ALL)
	private List<EprodutoEntity> produtos;



public Double getValorTotal() {
	
	if (quantidade != null && valorUnitario !=null) {
		
		return (quantidade * valorUnitario);
	}
	
	return 0.0;
}	
}