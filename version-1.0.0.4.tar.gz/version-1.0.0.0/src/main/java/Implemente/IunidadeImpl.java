package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DunidadeDTO;
import Entity.EunidadeEntity;
import MapStruct.MunidadeMapStruct;
import Repository.RunidadeRepository;
import Service.SunidadeService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IunidadeImpl implements SunidadeService {

	private RunidadeRepository repository;
	private MunidadeMapStruct mapper;

	@Override
	public List<DunidadeDTO> findAll() {
		List<EunidadeEntity> entities = repository.findAll();
		return entities.stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DunidadeDTO findById(Integer id) {
		EunidadeEntity entity = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Unidade com ID: " + id + " não encontrado."));

		return mapper.toDto(entity);
	}

	@Override
	public Optional<DunidadeDTO> save(DunidadeDTO dto) {
		EunidadeEntity entity = mapper.toEntity(dto);
		EunidadeEntity savedEntity = repository.save(entity);

		return Optional.of(mapper.toDto(savedEntity));
	}

	@Override
	public void deleteById(Integer id) {
		repository.deleteById(id);

	}

	@Override
	public List<EunidadeEntity> findByFirstNomeContaining(String palavraChave) {
		   if (palavraChave == null || palavraChave.trim().isEmpty()) {
	            return List.of();
	        }
	        
	        return repository.findByFirstNomeContaining(palavraChave);

}
