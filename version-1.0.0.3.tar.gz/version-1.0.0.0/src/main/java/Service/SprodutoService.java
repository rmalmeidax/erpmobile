package Service;

import java.util.List;
import java.util.Optional;

import DTO.DprodutoDTO;

public interface SprodutoService {

	List<DprodutoDTO> findAll();

	DprodutoDTO findById(Integer id);

	Optional<DprodutoDTO> save(DprodutoDTO dto);

	void deleteById(Integer id);

}
