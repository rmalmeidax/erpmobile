package Entity;

import java.util.ArrayList;
import java.util.List;

import Heranca.ProdutoBase;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name ="tb_vendas")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EvendasEntity extends ProdutoBase {

	@ManyToMany(mappedBy = "vendas")
	private List<EestoqueEntity> estoque = new ArrayList<>();

	@ManyToMany
	@JoinTable(name = "tb_vendas_cliente", joinColumns = @JoinColumn(name = "vendas_id"), inverseJoinColumns = @JoinColumn(name = "cliente_id")

	)
	private List<EclienteEntity> clientes = new ArrayList<>();

	

}
