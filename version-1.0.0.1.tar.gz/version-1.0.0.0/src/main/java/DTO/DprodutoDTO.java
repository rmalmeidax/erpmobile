package DTO;

import Entity.EfornecedorEntity;
import Entity.EunidadeEntity;
import Heranca.HDherancaBaseDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class DprodutoDTO  extends HDherancaBaseDTO{
	
	private EfornecedorEntity fornecedor;
	private EunidadeEntity unidade;
	

}
