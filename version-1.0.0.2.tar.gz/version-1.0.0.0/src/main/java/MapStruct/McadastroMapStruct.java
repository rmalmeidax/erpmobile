package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DcadastroDTO;
import Entity.EcadastroEntity;

@Mapper(componentModel = "spring") //integração com spring

public interface McadastroMapStruct {

	McadastroMapStruct cadastro = Mappers.getMapper(McadastroMapStruct.class);

	// Entity -> DTO

	DcadastroDTO toDto(EcadastroEntity entity);

	// DTO -> Entity

	EcadastroEntity toEntity(DcadastroDTO dto);

}
