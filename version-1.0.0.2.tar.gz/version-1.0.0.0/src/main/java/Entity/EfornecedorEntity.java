package Entity;

import java.util.ArrayList;
import java.util.List;

import Heranca.Cadastro;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tb_fornecedor")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EfornecedorEntity  extends Cadastro{
	
	@OneToMany(mappedBy = "fornecedor", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<EcadastroEntity> cadastro = new ArrayList<>();
	
	
	
	@ManyToMany	
	@JoinTable(name = "tb_produtoFornecedor",
	joinColumns = @JoinColumn (name = "fornecedor_id"),
	inverseJoinColumns = @JoinColumn (name = "produtos_id")
	)
	private List<EprodutoEntity> produtos = new ArrayList<>();


}
