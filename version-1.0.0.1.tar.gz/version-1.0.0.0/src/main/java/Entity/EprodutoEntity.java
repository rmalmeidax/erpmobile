package Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="tb_produto")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode (of = "id")

public class EprodutoEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "nome", length = 100)
	private String nome;
	@Column(name ="quantidade", precision = 8, scale = 2)
	private Double quantidade;
	@Column(name = "valor_unitario", precision = 8, scale = 2)
	private Double valorUnitario;
	@Column (name = "ncm", length = 10)
	private String ncm;
	
	@Transient
	private Double valorTotal;
	
	
	@ManyToMany(mappedBy = "produtos")
	private List <EfornecedorEntity> fornecedores = new ArrayList<>();
	
	@ManyToMany(mappedBy = "produtos")
	private List <EunidadeEntity>  unidades = new ArrayList<>();
	
	@ManyToMany(mappedBy = "produtos")
	private List<EestoqueEntity> estoque = new ArrayList<>();

	
	
	public Double getValorTotal(){
		if (quantidade != null && valorUnitario != null) {
			
			return quantidade * valorUnitario;
		}
		
		return 0.0;
		
	
		
	}
	
	
}

