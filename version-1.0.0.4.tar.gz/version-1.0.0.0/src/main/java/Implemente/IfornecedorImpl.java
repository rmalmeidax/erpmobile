package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DfornecedorDTO;
import Entity.EfornecedorEntity;
import MapStruct.MfornecedorMapStruct;
import Repository.RfornecedorRepository;
import Service.SfornecedorService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IfornecedorImpl implements SfornecedorService {

	private RfornecedorRepository repository;
	private MfornecedorMapStruct mapper;

	@Override
	public List<DfornecedorDTO> findAll() {
		List<EfornecedorEntity> entities = repository.findAll();
		return entities.stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DfornecedorDTO findById(Integer id) {
		EfornecedorEntity entity = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Fornecedor com ID: " + id + " não encontrado."));

		return mapper.toDto(entity);
	}

	@Override
	public Optional<DfornecedorDTO> save(DfornecedorDTO dto) {
		EfornecedorEntity entity = mapper.toEntity(dto);
		EfornecedorEntity savedEntity = repository.save(entity);

		return Optional.of(mapper.toDto(savedEntity));
	}

	@Override
	public void deleteById(Integer id) {
		repository.deleteById(id);

	}

	@Override
	public List<EfornecedorEntity> findByFirstNomeContaining(String palavraChave) {
		if (palavraChave == null || palavraChave.trim().isEmpty()) {
			return List.of();
		}

		return repository.findByFirstNomeContaining(palavraChave);
	}

}
