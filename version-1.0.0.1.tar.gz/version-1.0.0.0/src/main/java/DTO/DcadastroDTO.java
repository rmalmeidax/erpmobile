package DTO;

import Heranca.HDcadastroHerancaDTO;

public class DcadastroDTO extends HDcadastroHerancaDTO {

}
