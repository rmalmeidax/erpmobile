package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DestoqueDTO;
import Entity.EestoqueEntity;
import MapStruct.MestoqueMapStruct;
import Repository.RestoqueRepository;
import Service.SestoqueService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class IestoqueImpl implements SestoqueService {

    private RestoqueRepository repository;
    private MestoqueMapStruct mapper;

    @Override
    public List<DestoqueDTO> findAll() {
        List<EestoqueEntity> entities = repository.findAll();
        return entities.stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public DestoqueDTO findById(Integer id) {
        EestoqueEntity entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Estoque com ID: " + id + " não encontrado."));
        
        return mapper.toDto(entity);
    }

    @Override
    public Optional<DestoqueDTO> save(DestoqueDTO dto) {
        EestoqueEntity entity = mapper.toEntity(dto);
        EestoqueEntity savedEntity = repository.save(entity);
        
        return Optional.of(mapper.toDto(savedEntity));
    }

    @Override
    public void deleteById(Integer id) {
        repository.deleteById(id);
    }

    @Override
    public List<DestoqueDTO> findByFirstNomeContaining(String palavraChave) {
        if (palavraChave == null || palavraChave.trim().isEmpty()) {
            return List.of();
        }
        List <EestoqueEntity> entity = repository.findByFirstNomeContaining(palavraChave);
        
        return entity.stream().map(mapper::toDto).collect(Collectors.toList());
    }
    
}