package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DclienteDTO;
import Entity.EclienteEntity;

@Mapper(componentModel = "spring")

public interface MclienteMapStruct {
	
	MclienteMapStruct cliente = Mappers.getMapper(MclienteMapStruct.class);
	
	DclienteDTO toDto(EclienteEntity entity);
	
	EclienteEntity toEntity(DclienteDTO dto);

}
