package DTO;

import Entity.EfornecedorEntity;
import Entity.EprodutoEntity;
import Heranca.HDherancaBaseDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor



public class DcomprasDTO extends HDherancaBaseDTO {

	
	private EfornecedorEntity fornecedor;
	private EprodutoEntity produto;
	
	

}
