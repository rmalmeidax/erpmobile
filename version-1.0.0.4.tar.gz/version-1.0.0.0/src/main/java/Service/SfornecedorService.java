package Service;

import java.util.List;
import java.util.Optional;

import DTO.DfornecedorDTO;
import Entity.EfornecedorEntity;
import Entity.EprodutoEntity;

public interface SfornecedorService {

	List<DfornecedorDTO> findAll();

	DfornecedorDTO findById(Integer id);

	Optional<DfornecedorDTO> save(DfornecedorDTO dto);

	void deleteById(Integer id);

	List<EfornecedorEntity> findByFirstNomeContaining(String palavraChave);
}
