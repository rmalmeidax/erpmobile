package Entity;

import java.util.ArrayList;
import java.util.List;

import Heranca.ProdutoBase;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="tb_produto")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EprodutoEntity extends ProdutoBase{
	
	
	

	@ManyToMany(mappedBy = "produtos")
	private List <EfornecedorEntity> fornecedores = new ArrayList<>();
	
	@ManyToMany(mappedBy = "produtos")
	private List <EunidadeEntity>  unidades = new ArrayList<>();
	
	@ManyToMany(mappedBy = "produtos")
	private List<EestoqueEntity> estoque = new ArrayList<>();

	
		
		
	}
	
	


