package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DprodutoDTO;
import Entity.EprodutoEntity;
import MapStruct.MprodutoMapStruct;
import Repository.RprodutoRepository;
import Service.SprodutoService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IprodutoImpl implements SprodutoService {

	private RprodutoRepository repository;
	private MprodutoMapStruct mapper;

	@Override
	public List<DprodutoDTO> findAll() {
		List<EprodutoEntity> entities = repository.findAll();
		return entities.stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DprodutoDTO findById(Integer id) {
		EprodutoEntity entity = repository.findById(id)
				.orElseThrow(() -> new RuntimeException("Produto com ID: " + id + " não encontrado."));

		return mapper.toDto(entity);
	}

	@Override
	public Optional<DprodutoDTO> save(DprodutoDTO dto) {
		EprodutoEntity entity = mapper.toEntity(dto);
		EprodutoEntity savedEntity = repository.save(entity);

		return Optional.of(mapper.toDto(savedEntity));
	}

	@Override
	public void deleteById(Integer id) {
		repository.deleteById(id);

	}

	@Override
	public List<EprodutoEntity> findByFirstNomeContaining(String palavraChave) {
		if (palavraChave == null || palavraChave.trim().isEmpty()) {
			return List.of();
		}

		return repository.findByFirstNomeContaining(palavraChave);
	}

}
