package Enum;

public enum EunidadeEnum {
	
	UN("Unidade"),
    CX("Caixa"),
    KG("Quilograma"),
    G("Grama"),
    MG("Miligramas"),
    L("Litro"),
    ML("Mililitro"),
    M("Metro"),
    CM("Centímetro"),
    MM("Milímetro"),
    M2("Metro Quadrado"),
    M3("Metro Cúbico"),
    PCT("Pacote"),
    PAR("Par"),
    DZ("Dúzia"),
    TON("Tonelada");
	
	public String getDescricao() {
		return descricao;
	}

	private final String descricao;

	private EunidadeEnum(String descricao) {
		this.descricao = descricao;
	}
	
	
	
	
	
	
	


}
