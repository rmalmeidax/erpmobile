package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EcadastroEntity;

public interface RcadastroRepository extends JpaRepository<EcadastroEntity, Integer> {
	
	List<EcadastroEntity> findByFirstNomeContaining (String palavraChave);

}
