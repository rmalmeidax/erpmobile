package Service;

import java.util.List;
import java.util.Optional;

import DTO.DestoqueDTO;
import Entity.EestoqueEntity;
import Entity.EprodutoEntity;

public interface SestoqueService {
	
	List<DestoqueDTO> findAll();

	DestoqueDTO findById(Integer id);

	Optional<DestoqueDTO> save(DestoqueDTO dto);

	void deleteById(Integer id);
	
	List<DestoqueDTO> findByFirstNomeContaining (String palavraChave);
	
	

}
