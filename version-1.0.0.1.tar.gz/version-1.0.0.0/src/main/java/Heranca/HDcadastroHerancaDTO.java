package Heranca;

import Enum.EestadosBrEnum;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Inheritance(strategy = InheritanceType.JOINED)


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode (of = "id")

public class HDcadastroHerancaDTO {

	private Integer id;
	private String nome;
	private String cpf;
	private String cnpj;
	private String endereco;
	private Integer numero;
	private String bairro;
	private String cidade;
	private EestadosBrEnum estados;
	private String cep;
	private String email;

}
