package Service;

import java.util.List;
import java.util.Optional;

import DTO.DcomprasDTO;
import Entity.EcomprasEntity;
import Entity.EprodutoEntity;

public interface ScomprasService {
	
	List<DcomprasDTO> findAll();

	DcomprasDTO findById(Integer id);

	Optional<DcomprasDTO> save(DcomprasDTO dto);

	void deleteById(Integer id);
	
	List<DcomprasDTO> findByFirstNomeContaining (String palavraChave);
	
	
	

}
