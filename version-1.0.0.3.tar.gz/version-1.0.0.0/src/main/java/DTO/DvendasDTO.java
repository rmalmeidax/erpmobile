package DTO;

import Entity.EclienteEntity;
import Entity.EprodutoEntity;
import Heranca.ProdutoBaseDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor


public class DvendasDTO extends ProdutoBaseDTO {
	
	
	private EclienteEntity cliente;
	private EprodutoEntity produto;
	
	
	
	
	
	
	
	
	
	
	
	
	

}
