package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EprodutoEntity;

public interface RprodutoRepository extends JpaRepository<EprodutoEntity, Integer>{
	
	List<EprodutoEntity> findByFirstNomeContaining (String palavraChave);

}
