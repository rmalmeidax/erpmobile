package Service;

import java.util.List;
import java.util.Optional;

import DTO.DcomprasDTO;

public interface ScomprasService {
	
	List<DcomprasDTO> findAll();

	DcomprasDTO findById(Integer id);

	Optional<DcomprasDTO> save(DcomprasDTO dto);

	void deleteById(Integer id);
	
	
	
	
	

}
