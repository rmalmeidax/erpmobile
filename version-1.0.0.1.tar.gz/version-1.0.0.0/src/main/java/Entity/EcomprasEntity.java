package Entity;

import java.util.ArrayList;
import java.util.List;

import Heranca.HherancaBase;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;

/**
 * 
 */
@Entity
@Table(name = "tb_compras")
@NoArgsConstructor
public class EcomprasEntity extends HherancaBase {
	
	
	
	@ManyToMany(mappedBy = "compras")
	
	private List<EestoqueEntity> estoque = new ArrayList<>();

	@ManyToMany
	@JoinTable(name = "tb_compras_fornecedor", joinColumns = @JoinColumn(name = "compras_id"), 
	inverseJoinColumns = @JoinColumn(name = "fornecedor_id")

	)
	private List<EfornecedorEntity> fornecedores = new ArrayList<>();

	public List<EestoqueEntity> getEstoque() {
		return estoque;
	}

	public void setEstoque(List<EestoqueEntity> estoque) {
		this.estoque = estoque;
	}

	public List<EfornecedorEntity> getFornecedores() {
		return fornecedores;
	}

	public void setFornecedores(List<EfornecedorEntity> fornecedores) {
		this.fornecedores = fornecedores;
	}

	public EcomprasEntity(Integer id, Integer numeroProduto, Double quantidade, Double valorUnitario, Double valorTotal,
			List<EprodutoEntity> produtos, List<EestoqueEntity> estoque, List<EfornecedorEntity> fornecedores) {
		super(id, numeroProduto, quantidade, valorUnitario, valorTotal, produtos);
		this.estoque = estoque;
		this.fornecedores = fornecedores;
	}


	
}
