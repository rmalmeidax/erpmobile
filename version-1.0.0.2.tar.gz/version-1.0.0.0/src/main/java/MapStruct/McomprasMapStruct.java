package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DcomprasDTO;
import Entity.EcomprasEntity;

@Mapper(componentModel = "spring")

public interface McomprasMapStruct {

	McomprasMapStruct compras = Mappers.getMapper(McomprasMapStruct.class);

	DcomprasDTO toDto(EcomprasEntity entity);
	
	EcomprasEntity toEntity(DcomprasDTO dto);

}
