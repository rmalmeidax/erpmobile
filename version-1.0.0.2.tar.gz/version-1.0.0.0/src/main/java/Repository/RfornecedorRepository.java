package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EfornecedorEntity;

public interface RfornecedorRepository extends JpaRepository<EfornecedorEntity, Integer>{
	
	List<EfornecedorEntity> findByFirstNomeContaining (String palavraChave);

}
