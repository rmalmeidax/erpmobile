package Heranca;

import java.util.List;
import java.util.Objects;

import Entity.EprodutoEntity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class HherancaBase {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "numeroProduto")
	private Integer numeroProduto;
	@Column(name = "quantidade")
	private Double quantidade;
	@Column(name = "valorUnitario")
	private Double valorUnitario;
	@Transient
	private Double valorTotal;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "hheranca_id")
	private List<EprodutoEntity> produtos;

	public HherancaBase(Integer id, Integer numeroProduto, Double quantidade, Double valorUnitario, Double valorTotal,
			List<EprodutoEntity> produtos) {
		super();
		this.id = id;
		this.numeroProduto = numeroProduto;
		this.quantidade = quantidade;
		this.valorUnitario = valorUnitario;
		this.valorTotal = valorTotal;
		this.produtos = produtos;
	}

	public HherancaBase() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNumeroProduto() {
		return numeroProduto;
	}

	public void setNumeroProduto(Integer numeroProduto) {
		this.numeroProduto = numeroProduto;
	}

	public Double getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Double quantidade) {
		this.quantidade = quantidade;
	}

	public Double getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(Double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public List<EprodutoEntity> getProdutos() {
		return produtos;
	}

	public void setProdutos(List<EprodutoEntity> produtos) {
		this.produtos = produtos;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HherancaBase other = (HherancaBase) obj;
		return Objects.equals(id, other.id);
	}

	public Double getValorTotal() {
		
		if (quantidade != null && valorUnitario !=null) {
			
			return (quantidade * valorUnitario);
		}
		
		return 0.0;
		
	}
	
}
