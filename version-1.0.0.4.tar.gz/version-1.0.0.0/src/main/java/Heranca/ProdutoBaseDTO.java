package Heranca;

import jakarta.persistence.Column;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Builder
@Inheritance(strategy = InheritanceType.JOINED)

public class ProdutoBaseDTO {

	private Integer id;

	@NotBlank(message = "Campo obrigatório.")
	@Column(name = "numProd", precision = 8)
	private Integer numeroProduto;

	@NotBlank(message = "Campo obrigatório.")
	@Column(name = "quantidade", precision = 8, scale = 2)
	private Double quantidade;

	@NotBlank(message = "Campo obrigatório.")
	@Column(name = "vrlUnit", precision = 8, scale = 2)
	private Double valorUnitario;

	@NotBlank(message = "Campo obrigatório.")
	@Column(name = "vrlTot", precision = 8, scale = 2)
	private Double valorTotal;

}
