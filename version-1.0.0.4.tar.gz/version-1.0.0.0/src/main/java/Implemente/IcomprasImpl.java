package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DcomprasDTO;
import Entity.EcomprasEntity;
import MapStruct.McomprasMapStruct;
import Repository.RcomprasRepository;
import Service.ScomprasService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IcomprasImpl implements ScomprasService {

	private RcomprasRepository repository;
	private McomprasMapStruct mapper;

	@Override
	public List<DcomprasDTO> findAll() {
		List<EcomprasEntity> entity = repository.findAll();
		return entity.stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DcomprasDTO findById(Integer id) {
	    EcomprasEntity entity = repository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Compras com ID: " + id + " não encontrado."));

	    return mapper.toDto(entity);
	}

	@Override
	public Optional<DcomprasDTO> save(DcomprasDTO dto) {
		EcomprasEntity entity = mapper.toEntity(dto);
		EcomprasEntity entitySave = repository.save(entity);

		return Optional.of(mapper.toDto(entitySave));
	}

	@Override
	public void deleteById(Integer id) {
		repository.deleteById(id);

	}

	@Override
	public List<DcomprasDTO> findByFirstNomeContaining(String palavraChave) {
	    if (palavraChave == null || palavraChave.trim().isEmpty()) {
	        return List.of();
	    }

	    List<EcomprasEntity> entity = repository.findByFirstNomeContaining(palavraChave);
	    return entity.stream().map(mapper::toDto).collect(Collectors.toList());
	}
	
}
