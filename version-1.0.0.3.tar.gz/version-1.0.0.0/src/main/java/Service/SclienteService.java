package Service;

import java.util.List;
import java.util.Optional;

import DTO.DclienteDTO;

public interface SclienteService {

	List<DclienteDTO> findAll();

	DclienteDTO findById(Integer id);

	Optional<DclienteDTO> save(DclienteDTO dto);

	void deleteById(Integer id);

}
