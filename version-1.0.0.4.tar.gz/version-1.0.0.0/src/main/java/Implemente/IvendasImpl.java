package Implemente;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import DTO.DvendasDTO;
import Entity.EvendasEntity;
import MapStruct.MvendasMapStruct;
import Repository.RvendasRepository;
import Service.SvendasService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class IvendasImpl implements SvendasService {
	
	private RvendasRepository repository;
	private MvendasMapStruct mapper;
	
	
	
	
	@Override
	public List<DvendasDTO> findAll() {
		List<EvendasEntity> entities = repository.findAll();
        return entities.stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }
	}
	@Override
	public DvendasDTO findById(Integer id) {
		   EvendasEntity entity = repository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Vendas com ID: " + id + " não encontrado."));
	        
	        return mapper.toDto(entity);
	}
	@Override
	public Optional<DvendasDTO> save(DvendasDTO dto) {
		EvendasEntity entity = mapper.toEntity(dto);
        EvendasEntity savedEntity = repository.save(entity);
        
        return Optional.of(mapper.toDto(savedEntity));
	}
	@Override
	public void deleteById(Integer id) {
		 repository.deleteById(id);
		
	}
	@Override
	public List<EvendasEntity> findByFirstNomeContaining(String palavraChave) {
		// TODO Auto-generated method stub
		 if (palavraChave == null || palavraChave.trim().isEmpty()) {
	            return List.of();
	        }
	        
	        return repository.findByFirstNomeContaining(palavraChave);
	}	
	

}
