package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DvendasDTO;
import Entity.EvendasEntity;

@Mapper(componentModel = "Spring")

public interface MvendasMapStruct {

	MvendasMapStruct vendas = Mappers.getMapper(MvendasMapStruct.class);

	DvendasDTO toDto(EvendasEntity entity);

	EvendasEntity toEntity(DvendasDTO dto);

}
