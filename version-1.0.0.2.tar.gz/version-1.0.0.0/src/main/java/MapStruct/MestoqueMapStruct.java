package MapStruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import DTO.DestoqueDTO;
import Entity.EestoqueEntity;

@Mapper(componentModel = "spring")

public interface MestoqueMapStruct {

	MestoqueMapStruct estoque = Mappers.getMapper(MestoqueMapStruct.class);

	DestoqueDTO toDto(EestoqueEntity entity);

	EestoqueEntity toEntity(DestoqueDTO dto);

}
