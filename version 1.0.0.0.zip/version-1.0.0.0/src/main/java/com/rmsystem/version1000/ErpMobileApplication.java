package com.rmsystem.version1000;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpMobileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpMobileApplication.class, args);
	}

}
