package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Entity.EclienteEntity;

public interface RclienteRepository  extends JpaRepository<EclienteEntity, Integer>{
	
	List<EclienteEntity> findByFirstNomeContaining (String palavraChave);

}
